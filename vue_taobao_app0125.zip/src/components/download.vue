<template>
  <div class="download">
    <h1>欢迎下载淘宝App</h1>
  </div>
</template>

<script>
export default {
  name: 'download',
  data () {
    return {
    }
  },
  created(){
  },
  mounted(){
  },
  methods:{

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >
</style>
