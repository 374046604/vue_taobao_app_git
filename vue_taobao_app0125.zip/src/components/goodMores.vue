<template>
  <div class="good_mores">
    <swiper class="swiper" loop auto dots-position="center"  height="10rem" :interval="30000" :duration="500">
        <swiper-item class="swiper-demo-img" v-for="(item, index) in demo04_list" :key="index">
          <a href="#/bannerList"><img :src="item"></a>
        </swiper-item>
      </swiper>
  </div>
</template>

<script>
import axios from 'axios'
import { Swiper, SwiperItem } from "vux";
export default {
  name: 'good_mores',
  data () {
    return {
      demo04_list:[]
    }
  },
  created(){
  },
  components:{
    Swiper, SwiperItem  
  },
  mounted(){
    var _this=this;
    console.log(_this.$route.query.id);
    axios({
      method: 'get',
      url: 'http://127.0.0.1:3000/goods/getMore',
      params: {
        goodId: _this.$route.query.id,
      },
      //data:data,
      responseType: 'json',
    })
    .then(function (response) {
      _this.demo04_list=response.data[0].goodImg;
    })
    .catch(function (error) {
      console.log(error);
    });
  },
  methods:{

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
@import "../assets/css/common_sass.scss";
@import "../assets/css/page/goodMores.scss";
</style>
