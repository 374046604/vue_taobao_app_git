<template>
  <div class="home">
  aaaaaaaaa
  </div>
</template>

<script>
export default {
  name: 'home',
  data () {
    return {
    }
  },
  created(){
  },
  mounted(){
  },
  methods:{

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >
</style>
